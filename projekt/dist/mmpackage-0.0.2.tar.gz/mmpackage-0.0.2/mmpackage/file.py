def greetings():
    print("Hello")